package ir.lexora.app

import ir.lexora.app.data.PersianText
import org.junit.Assert.assertEquals
import org.junit.Test

class PersianTextTest {
    @Test fun arabicYeAndKafAreUnified() {
        assertEquals("کتاب یک", PersianText.sanitize("كتاب يك"))
    }

    @Test fun halfSpaceAndSpaceMatch() {
        assertEquals(PersianText.searchKey("وکالت\u200Cنامه"), PersianText.searchKey("وکالت نامه"))
    }

    @Test fun diacriticsAreIgnored() {
        assertEquals(PersianText.searchKey("وَکالَت"), PersianText.searchKey("وکالت"))
    }

    @Test fun hamzaAndAlefMatch() {
        assertEquals(PersianText.searchKey("إیقاع"), PersianText.searchKey("ایقاع"))
    }
}
