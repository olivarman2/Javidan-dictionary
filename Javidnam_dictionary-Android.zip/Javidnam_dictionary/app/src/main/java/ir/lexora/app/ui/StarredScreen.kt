package ir.lexora.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Page that lists every starred word. Tap a word to open it; tap its star to remove it. */
@Composable
fun StarredScreen(vm: LexoraViewModel) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.showStarred = false }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت", tint = Color.White)
            }
            Text("کلمات ستاره‌دار", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .glass(RoundedCornerShape(28.dp), 0.14f)
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                "اصطلاح‌هایی که با ستاره علامت زده‌اید (${vm.favorites.size}).",
                color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp, lineHeight = 22.sp
            )
            if (vm.favorites.isEmpty()) {
                Text(
                    "هنوز کلمه‌ای را ستاره‌دار نکرده‌اید.",
                    color = Color.White.copy(alpha = 0.7f), fontSize = 15.sp,
                    modifier = Modifier.padding(vertical = 24.dp)
                )
            }
            vm.favorites.forEach { fav ->
                WordRow(fav.displayTitle, vm) {
                    vm.showStarred = false
                    vm.openFavorite(fav)
                }
            }
        }
    }
}
