package ir.lexora.app.ui

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.lexora.app.data.LocalRepository
import ir.lexora.app.data.ResultMode
import ir.lexora.app.data.TermResult
import ir.lexora.app.data.toPlainText

@Composable
fun HomeScreen(vm: LexoraViewModel) {
    val focus = LocalFocusManager.current
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { vm.menuOpen = true }) {
                Icon(Icons.Filled.Menu, contentDescription = "منو", tint = Color.White)
            }
            Text(
                text = "ترمینولوژی حقوقی جاویدان",
                color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(48.dp))
        }

        SearchBox(
            value = vm.query,
            onValueChange = vm::onQueryChange,
            onClear = vm::clearQuery,
            onSearch = { focus.clearFocus(); vm.search() }
        )

        if (vm.suggestions.isNotEmpty()) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp)
                    .heightIn(max = 300.dp)
                    .glass(RoundedCornerShape(20.dp), 0.2f)
                    .background(Color(0x66100F22))
                    .verticalScroll(rememberScrollState())
            ) {
                vm.suggestions.forEach { s ->
                    Text(
                        s,
                        color = Color.White, fontSize = 17.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { focus.clearFocus(); vm.query = s; vm.search(s) }
                            .padding(horizontal = 18.dp, vertical = 12.dp)
                    )
                }
            }
        }

        Text(
            text = if (vm.isOnlineConfigured) "حالت آنلاین · آدرس سرور تنظیم شده است"
            else "پایگاه داده داخلی · ${vm.termCount} اصطلاح · بدون نیاز به اینترنت",
            color = Color.White.copy(alpha = 0.72f),
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)
        )

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .glass(RoundedCornerShape(28.dp), 0.14f)
        ) {
            Crossfade(targetState = vm.uiState, label = "panel") { state ->
                when (state) {
                    UiState.Idle -> IdleContent(vm)
                    UiState.Loading -> LoadingContent()
                    is UiState.Content -> ResultContent(vm, state.result)
                    is UiState.Message -> MessageContent(vm, state)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun SearchBox(value: String, onValueChange: (String) -> Unit, onClear: () -> Unit, onSearch: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().glass(RoundedCornerShape(30.dp), 0.18f),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.weight(1f),
            singleLine = true,
            textStyle = TextStyle(fontSize = 18.sp),
            placeholder = { Text("جست‌وجو کنید", color = Color.White.copy(alpha = 0.65f), fontSize = 18.sp) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { onSearch() }),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                disabledContainerColor = Color.Transparent,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                cursorColor = Color.White,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )
        if (value.isNotEmpty()) {
            IconButton(onClick = onClear) {
                Icon(Icons.Filled.Clear, contentDescription = "پاک کردن", tint = Color.White.copy(alpha = 0.85f))
            }
        }
        IconButton(onClick = onSearch, modifier = Modifier.padding(end = 4.dp)) {
            Icon(Icons.Filled.Search, contentDescription = "جست‌وجو", tint = Color.White)
        }
    }
}

@Composable
private fun LoadingContent() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            CircularProgressIndicator(color = Color.White)
            Text("در حال جست‌وجو…", color = Color.White.copy(alpha = 0.85f))
        }
    }
}

@Composable
private fun MessageContent(vm: LexoraViewModel, state: UiState.Message) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(
                state.text,
                color = if (state.isError) Color(0xFFFFB4B4) else Color.White,
                fontSize = 16.sp,
                lineHeight = 26.sp,
                textAlign = TextAlign.Center
            )
            if (state.isError) {
                Button(
                    onClick = { vm.search() },
                    colors = ButtonDefaults.buttonColors(containerColor = Rose, contentColor = Color(0xFF2A1040))
                ) { Text("تلاش دوباره") }
            }
        }
    }
}

@Composable
private fun IdleContent(vm: LexoraViewModel) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("تلفظ و معنای اصطلاحات حقوقی", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(
            "یک اصطلاح حقوقی را در کادر بالا بنویسید؛ با اعراب یا بدون اعراب فرقی نمی‌کند.",
            color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp, lineHeight = 22.sp
        )
        if (vm.favorites.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text("ستاره‌دارها", color = Rose, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            vm.favorites.forEach { fav ->
                WordRow(fav.displayTitle, vm) { vm.openFavorite(fav) }
            }
        }
        if (vm.history.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("تاریخچه", color = Rose, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = vm::clearHistory) { Text("پاک کردن", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp) }
            }
            vm.history.forEach { h ->
                WordRow(h, vm) { vm.query = h; vm.search(h) }
            }
        }
    }
}

@Composable
private fun ResultContent(vm: LexoraViewModel, r: TermResult) {
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val isFav = vm.isFavorite(r)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (r.mode == ResultMode.LOCAL) Badge(r.category?.let { "پایگاه داده داخلی · $it" } ?: "پایگاه داده داخلی", Color(0xFF9EF0C0))
        else Badge("نتیجه جست‌وجوی آنلاین", Color(0xFF9EF0C0))
        r.note?.let { Text(it, fontSize = 12.sp, lineHeight = 19.sp, color = Color.White.copy(alpha = 0.75f)) }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(r.displayTitle, Modifier.weight(1f), fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
            StarButton(on = isFav) { vm.toggleFavorite(r) }
        }
        if (r.category == LocalRepository.USER_CATEGORY) {
            TextButton(onClick = { vm.deleteUserTerm(r) }) {
                Text("حذف این اصطلاح", color = Color(0xFFFFB4B4))
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = {
                clipboard.setText(AnnotatedString(r.toPlainText()))
                Toast.makeText(context, "کپی شد", Toast.LENGTH_SHORT).show()
            }) { Text("کپی", color = Color.White) }
            TextButton(onClick = {
                runCatching {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, r.toPlainText())
                    }
                    context.startActivity(Intent.createChooser(send, "اشتراک‌گذاری"))
                }
            }) {
                Icon(Icons.Filled.Share, contentDescription = null, tint = Color.White)
                Spacer(Modifier.padding(horizontal = 3.dp))
                Text("اشتراک‌گذاری", color = Color.White)
            }
        }

        r.pronunciation?.let { Section("تلفظ", it) }
        r.generalMeaning?.let { Section("معنای عمومی", it) }
        r.legalMeaning?.let { Section("معنای حقوقی در نظام حقوقی ایران", it) }
        r.simpleExplanation?.let { Section("توضیح ساده", it) }
        if (r.examples.isNotEmpty()) {
            Section("مثال‌ها", r.examples.mapIndexed { i, e -> "${i + 1}. $e" }.joinToString("\n"))
        }
        if (r.similarTerms.isNotEmpty()) {
            Section("اصطلاحات مشابه", r.similarTerms.joinToString("\n\n") { "${it.term}: ${it.difference}" })
        }

        if (r.related.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("اصطلاحات مرتبط", color = Rose, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                r.related.forEach { name ->
                    WordRow(name, vm) { vm.query = name; vm.search(name) }
                }
            }
        }

        if (r.mode == ResultMode.ONLINE) {
            Text(
                "بخش‌های توضیحی بالا با هوش مصنوعی و بر پایه منابع بازیابی‌شده نوشته شده‌اند و جایگزین مشورت حقوقی نیستند.",
                fontSize = 12.sp, lineHeight = 19.sp, color = Color.White.copy(alpha = 0.7f)
            )
        }

        if (r.articles.isNotEmpty() || r.sources.isNotEmpty()) {
            Column(
                Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp), 0.1f).padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Badge("بازیابی‌شده از منبع (نه تولید هوش مصنوعی)", Color(0xFF9FD4FF))
                r.articles.forEach { a ->
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(a.reference, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                        Text("«${a.evidence}»", fontStyle = FontStyle.Italic, color = Color.White.copy(alpha = 0.88f), fontSize = 14.sp, lineHeight = 23.sp)
                        a.sourceUrl?.let { LinkText(it) }
                    }
                }
                r.sources.forEach { s ->
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(s.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        LinkText(s.url)
                        s.checkedAt?.let { Text("تاریخ بررسی: $it", color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp) }
                    }
                }
            }
        } else if (r.mode == ResultMode.ONLINE) {
            Text("منبع یا ماده قانونی قابل تأییدی همراه این نتیجه نبود.", color = Color(0xFFFFD28A), fontSize = 13.sp)
        }
    }
}

@Composable
private fun Section(label: String, body: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, color = Rose, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text(body, color = Color.White, fontSize = 16.sp, lineHeight = 27.sp)
    }
}

@Composable
private fun Badge(text: String, color: Color) {
    Text(
        text,
        color = color, fontSize = 12.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier
            .glass(RoundedCornerShape(50), 0.08f)
            .padding(horizontal = 12.dp, vertical = 5.dp)
    )
}

@Composable
private fun LinkText(url: String) {
    val handler = LocalUriHandler.current
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Text(
            url,
            color = LinkBlue, fontSize = 13.sp, textDecoration = TextDecoration.Underline,
            modifier = Modifier.clickable {
                if (url.startsWith("http://") || url.startsWith("https://")) runCatching { handler.openUri(url) }
            }
        )
    }
}

@Composable
internal fun StarButton(on: Boolean, onClick: () -> Unit) {
    IconButton(onClick = onClick) {
        Icon(
            Icons.Filled.Star,
            contentDescription = "ستاره",
            tint = if (on) Color(0xFFFFD54F) else Color.White.copy(alpha = 0.4f)
        )
    }
}

/** One word in a list: tap the word to open it, tap the star to mark it as favorite. */
@Composable
internal fun WordRow(name: String, vm: LexoraViewModel, onOpen: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            name,
            color = Color.White, fontSize = 17.sp,
            modifier = Modifier.weight(1f).clickable { onOpen() }.padding(vertical = 10.dp)
        )
        StarButton(on = vm.isStarred(name)) { vm.toggleStar(name) }
    }
}
