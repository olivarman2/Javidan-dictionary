package ir.lexora.app.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** The wallpaper behind every screen: the user's photo (or the built-in one) with adjustable blur. */
@Composable
fun PhotoBackground(vm: LexoraViewModel) {
    val context = LocalContext.current
    val base by produceState<Bitmap?>(null, vm.wallpaperVersion) {
        value = withContext(Dispatchers.IO) { Wallpaper.load(context) }
    }
    val shown by produceState<Bitmap?>(null, base, vm.bgBlur) {
        val b = base
        value = if (b == null) null else withContext(Dispatchers.Default) { Wallpaper.softBlur(b, vm.bgBlur) }
    }
    Box(Modifier.fillMaxSize()) {
        val img = shown
        if (img != null) {
            Image(
                bitmap = img.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alignment = Alignment.TopCenter
            )
        } else {
            SunsetBackground()
        }
        // A soft dark veil keeps the white text readable on any photo.
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0x26050510), Color(0x73050510)))
            )
        )
    }
}
