package ir.lexora.app.data

import android.content.Context
import ir.lexora.app.BuildConfig
import org.json.JSONArray
import org.json.JSONObject

/** Small local storage (SharedPreferences): search history, favorites and the backend address. */
class LocalStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("lexora", Context.MODE_PRIVATE)

    var backendUrl: String
        get() = prefs.getString(KEY_URL, null) ?: BuildConfig.DEFAULT_BACKEND_URL
        set(value) = prefs.edit().putString(KEY_URL, value).apply()

    var bgBlur: Float
        get() = prefs.getFloat(KEY_BLUR, 1.2f)
        set(value) = prefs.edit().putFloat(KEY_BLUR, value).apply()

    fun loadHistory(): List<String> = runCatching {
        JSONArray(prefs.getString(KEY_HISTORY, "[]")).strings()
    }.getOrDefault(emptyList())

    fun addHistory(query: String) {
        val key = PersianText.searchKey(query)
        val updated = (listOf(query) + loadHistory().filter { PersianText.searchKey(it) != key }).take(MAX_HISTORY)
        prefs.edit().putString(KEY_HISTORY, JSONArray(updated).toString()).apply()
    }

    fun clearHistory() = prefs.edit().remove(KEY_HISTORY).apply()

    fun loadFavorites(): List<TermResult> = runCatching {
        JSONArray(prefs.getString(KEY_FAVORITES, "[]")).objects().map { TermJson.fromStored(it) }
    }.getOrDefault(emptyList())

    fun saveFavorites(list: List<TermResult>) {
        val arr = JSONArray(list.map { TermJson.toJson(it) })
        prefs.edit().putString(KEY_FAVORITES, arr.toString()).apply()
    }

    fun loadUserTerms(): List<JSONObject> = runCatching {
        JSONArray(prefs.getString(KEY_USER, "[]")).objects()
    }.getOrDefault(emptyList())

    fun addUserTerm(term: JSONObject) {
        val arr = JSONArray()
        arr.put(term)
        loadUserTerms().forEach { arr.put(it) }
        prefs.edit().putString(KEY_USER, arr.toString()).apply()
    }

    fun removeUserTerm(key: String) {
        val kept = loadUserTerms().filter { PersianText.searchKey(it.optString("t")) != key }
        prefs.edit().putString(KEY_USER, JSONArray(kept).toString()).apply()
    }

    private companion object {
        const val KEY_USER = "user_terms"
        const val KEY_BLUR = "bg_blur"
        const val KEY_URL = "backend_url"
        const val KEY_HISTORY = "history"
        const val KEY_FAVORITES = "favorites"
        const val MAX_HISTORY = 30
    }
}
