package ir.lexora.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Second page: the user writes a term, its meaning and explanation, then taps "تأیید" at the bottom. */
@Composable
fun AddTermScreen(vm: LexoraViewModel) {
    var term by remember { mutableStateOf("") }
    var pron by remember { mutableStateOf("") }
    var meaning by remember { mutableStateOf("") }
    var explanation by remember { mutableStateOf("") }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color.White,
        unfocusedTextColor = Color.White,
        focusedBorderColor = Rose,
        unfocusedBorderColor = Color.White.copy(alpha = 0.4f),
        cursorColor = Color.White,
        focusedLabelColor = Rose,
        unfocusedLabelColor = Color.White.copy(alpha = 0.65f)
    )

    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding().padding(horizontal = 16.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.showAdd = false }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت", tint = Color.White)
            }
            Text("افزودن اصطلاح", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }

        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .glass(RoundedCornerShape(28.dp), 0.14f)
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                "اصطلاح را (ترجیحاً با اعراب)، معنا و توضیح آن را بنویسید و در پایین «تأیید» را بزنید. این اطلاعات فقط روی همین گوشی ذخیره می‌شود.",
                color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp, lineHeight = 22.sp
            )
            OutlinedTextField(
                value = term, onValueChange = { term = it }, modifier = Modifier.fillMaxWidth(),
                singleLine = true, label = { Text("اصطلاح") }, colors = fieldColors
            )
            OutlinedTextField(
                value = pron, onValueChange = { pron = it }, modifier = Modifier.fillMaxWidth(),
                singleLine = true, label = { Text("تلفظ (اختیاری)") }, colors = fieldColors
            )
            OutlinedTextField(
                value = meaning, onValueChange = { meaning = it }, modifier = Modifier.fillMaxWidth(),
                minLines = 2, label = { Text("معنا") }, colors = fieldColors
            )
            OutlinedTextField(
                value = explanation, onValueChange = { explanation = it }, modifier = Modifier.fillMaxWidth(),
                minLines = 3, label = { Text("توضیح") }, colors = fieldColors
            )
            vm.addError?.let { Text(it, color = Color(0xFFFFB4B4), fontSize = 13.sp) }
        }

        Spacer(Modifier.height(10.dp))
        Button(
            onClick = { vm.submitTerm(term, pron, meaning, explanation) },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Rose, contentColor = Color(0xFF2A1040))
        ) { Text("تأیید", fontSize = 17.sp, fontWeight = FontWeight.Bold) }
        TextButton(onClick = { vm.showAdd = false }, modifier = Modifier.fillMaxWidth()) {
            Text("انصراف", color = Color.White.copy(alpha = 0.85f))
        }
        Spacer(Modifier.height(6.dp))
    }
}
