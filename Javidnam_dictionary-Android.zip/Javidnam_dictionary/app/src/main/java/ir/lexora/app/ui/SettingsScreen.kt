package ir.lexora.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions

@Composable
fun SettingsScreen(vm: LexoraViewModel) {
    var url by remember { mutableStateOf(vm.backendUrl) }
    var saved by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.importWallpaper(uri)
    }
    val urlOk = url.isBlank() || LexoraViewModel.isValidBackendUrl(url)

    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.showSettings = false }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت", tint = Color.White)
            }
            Text("تنظیمات", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }

        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .glass(RoundedCornerShape(28.dp), 0.14f)
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("آدرس سرور (Backend)", color = Rose, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(
                "اختیاری: برای جست‌وجوی آنلاین، آدرس HTTPS سرور خودتان را اینجا بنویسید. " +
                    "اگر خالی بماند (پیشنهادی)، برنامه فقط از پایگاه داده داخلی استفاده می‌کند و اینترنت لازم نیست. " +
                    "کلید API هرگز در برنامه نگهداری نمی‌شود و فقط روی سرور است.",
                color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp, lineHeight = 22.sp
            )
            OutlinedTextField(
                value = url,
                onValueChange = { url = it; saved = false },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                isError = !urlOk,
                label = { Text("https://your-server.example.com") },
                textStyle = TextStyle(textDirection = TextDirection.Ltr, fontSize = 15.sp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = Rose,
                    unfocusedBorderColor = Color.White.copy(alpha = 0.4f),
                    cursorColor = Color.White,
                    focusedLabelColor = Rose,
                    unfocusedLabelColor = Color.White.copy(alpha = 0.6f)
                )
            )
            if (!urlOk) Text("آدرس باید با https:// شروع شود.", color = Color(0xFFFFB4B4), fontSize = 12.sp)
            Button(
                enabled = urlOk,
                onClick = { vm.saveBackendUrl(url); saved = true },
                colors = ButtonDefaults.buttonColors(containerColor = Rose, contentColor = Color(0xFF2A1040))
            ) { Text("ذخیره") }
            if (saved) Text(
                if (vm.isOnlineConfigured) "ذخیره شد. حالا جست‌وجوها به سرور شما ارسال می‌شود."
                else "ذخیره شد. برنامه در حالت آزمایشی است.",
                color = Color(0xFF9EF0C0), fontSize = 13.sp
            )

            Text("داده‌های روی گوشی", color = Rose, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp))
            OutlinedButton(onClick = vm::clearHistory) { Text("پاک کردن تاریخچه", color = Color.White) }
            OutlinedButton(onClick = vm::clearFavorites) { Text("پاک کردن ذخیره‌شده‌ها", color = Color.White) }

            Text("پس‌زمینه", color = Rose, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp))
            Button(
                onClick = { picker.launch("image/*") },
                colors = ButtonDefaults.buttonColors(containerColor = Rose, contentColor = Color(0xFF2A1040))
            ) { Text("انتخاب تصویر از گالری") }
            OutlinedButton(onClick = { vm.resetWallpaper() }) { Text("تصویر پیش‌فرض", color = Color.White) }
            Text(
                "میزان تاری (بلور): ${Math.round(vm.bgBlur * 10) / 10f}",
                color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp
            )
            Slider(
                value = vm.bgBlur,
                onValueChange = { vm.setBlur(it) },
                valueRange = 0f..20f,
                colors = SliderDefaults.colors(thumbColor = Rose, activeTrackColor = Rose)
            )

            Text("درباره", color = Rose, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp))
            Text(
                "جاویدان نسخه ۱٫۰\nتوضیحات این برنامه جنبه آموزشی دارد و مشاوره حقوقی نیست؛ برای کار رسمی به متن قانون و وکیل مراجعه کنید.",
                color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp, lineHeight = 22.sp
            )
        }
    }
}
