package ir.lexora.app.data

/**
 * Helpers for Persian text: unifies Arabic/Persian "ye" and "kaf", ZWNJ (half-space),
 * diacritics (harakat) and whitespace so that different spellings match each other.
 */
object PersianText {
    private val diacritics = Regex("[\\u0640\\u064B-\\u065F\\u0670]")
    private val whitespace = Regex("\\s+")

    /** Cleans user input (keeps spaces; ZWNJ becomes a normal space). */
    fun sanitize(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input) {
            val mapped = when (ch) {
                '\u064A', '\u0649' -> '\u06CC' // ي ى -> ی
                '\u0643' -> '\u06A9'           // ك -> ک
                '\u0629' -> '\u0647'           // ة -> ه
                '\u200C', '\u200D', '\u200E', '\u200F', '\u00A0' -> ' '
                else -> ch
            }
            if (mapped.isISOControl()) sb.append(' ') else sb.append(mapped)
        }
        return sb.toString().replace(diacritics, "").replace(whitespace, " ").trim()
    }

    /** Aggressive key used only for matching/comparison (no spaces, alef/hamza folded). */
    fun searchKey(input: String): String = sanitize(input)
        .replace('\u0622', '\u0627') // آ -> ا
        .replace('\u0623', '\u0627') // أ -> ا
        .replace('\u0625', '\u0627') // إ -> ا
        .replace('\u0624', '\u0648') // ؤ -> و
        .replace('\u0626', '\u06CC') // ئ -> ی
        .replace(" ", "")
}
