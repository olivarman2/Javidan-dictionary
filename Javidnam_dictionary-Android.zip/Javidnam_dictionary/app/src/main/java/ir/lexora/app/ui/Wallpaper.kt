package ir.lexora.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import ir.lexora.app.R
import java.io.File

/** Loads, imports and softly blurs the background photo. */
object Wallpaper {
    private fun file(context: Context) = File(context.filesDir, "wallpaper.jpg")

    /** The photo the user picked, or the built-in photo if none was picked. */
    fun load(context: Context): Bitmap? {
        val custom = file(context)
        if (custom.exists()) {
            BitmapFactory.decodeFile(custom.absolutePath)?.let { return it }
        }
        return BitmapFactory.decodeResource(context.resources, R.drawable.default_bg)
    }

    /** Copies a picked image into app storage, scaled down to at most 1600 px. */
    fun importFrom(context: Context, uri: Uri): Boolean = runCatching {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        if (bmp == null) {
            false
        } else {
            file(context).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            true
        }
    }.getOrDefault(false)

    fun reset(context: Context) {
        file(context).delete()
    }

    /** Cheap blur that works on every Android version: shrink the picture, then enlarge it. */
    fun softBlur(src: Bitmap, radius: Float): Bitmap {
        if (radius < 0.5f) return src
        val factor = 1f + radius / 2f
        val w = (src.width / factor).toInt().coerceAtLeast(8)
        val h = (src.height / factor).toInt().coerceAtLeast(8)
        val small = Bitmap.createScaledBitmap(src, w, h, true)
        return Bitmap.createScaledBitmap(small, src.width, src.height, true)
    }
}
