package ir.lexora.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Rose = Color(0xFFF2A1C2)
val LinkBlue = Color(0xFF9FD4FF)

@Composable
fun LexoraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Rose,
            onPrimary = Color(0xFF2A1040),
            surface = Color(0xFF1A1040),
            onSurface = Color.White
        ),
        content = content
    )
}
