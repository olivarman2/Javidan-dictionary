package ir.lexora.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/** Glassmorphism look: translucent white gradient + soft light border. */
fun Modifier.glass(shape: Shape = RoundedCornerShape(24.dp), alpha: Float = 0.16f): Modifier = this
    .clip(shape)
    .background(
        Brush.verticalGradient(
            listOf(Color.White.copy(alpha = alpha + 0.07f), Color.White.copy(alpha = (alpha - 0.05f).coerceAtLeast(0.03f)))
        )
    )
    .border(
        1.dp,
        Brush.linearGradient(listOf(Color.White.copy(alpha = 0.55f), Color.White.copy(alpha = 0.08f))),
        shape
    )

/** Sunset landscape drawn in code: dark blue -> purple -> soft pink sky, sun glow and mountains. */
@Composable
fun SunsetBackground(modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawRect(
            Brush.verticalGradient(
                0f to Color(0xFF0B1033),
                0.35f to Color(0xFF2A1B5E),
                0.62f to Color(0xFF7B3F98),
                0.82f to Color(0xFFE08AA9),
                1f to Color(0xFFF6B7B0)
            )
        )
        val sun = Offset(w * 0.5f, h * 0.76f)
        drawCircle(
            Brush.radialGradient(listOf(Color(0x77FFD2C0), Color.Transparent), center = sun, radius = w * 0.75f),
            radius = w * 0.75f, center = sun
        )
        drawCircle(Color(0xFFFFC9B5).copy(alpha = 0.92f), radius = w * 0.12f, center = sun)

        val far = Path().apply {
            moveTo(0f, h); lineTo(0f, h * 0.80f)
            quadraticBezierTo(w * 0.18f, h * 0.70f, w * 0.38f, h * 0.80f)
            quadraticBezierTo(w * 0.58f, h * 0.72f, w * 0.78f, h * 0.81f)
            quadraticBezierTo(w * 0.92f, h * 0.76f, w, h * 0.80f)
            lineTo(w, h); close()
        }
        drawPath(far, Color(0xFF3A1F6B).copy(alpha = 0.8f))
        val near = Path().apply {
            moveTo(0f, h); lineTo(0f, h * 0.89f)
            quadraticBezierTo(w * 0.25f, h * 0.82f, w * 0.5f, h * 0.90f)
            quadraticBezierTo(w * 0.75f, h * 0.84f, w, h * 0.90f)
            lineTo(w, h); close()
        }
        drawPath(near, Color(0xFF160B38).copy(alpha = 0.92f))
    }
}
