package ir.lexora.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun LexoraApp(vm: LexoraViewModel = viewModel()) {
    BackHandler(enabled = vm.menuOpen || vm.showSettings || vm.showAdd || vm.showMine || vm.showStarred) {
        if (vm.menuOpen) {
            vm.menuOpen = false
        } else {
            vm.showSettings = false
            vm.showAdd = false
            vm.showMine = false
            vm.showStarred = false
        }
    }
    // The whole UI is right-to-left for Persian.
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(Modifier.fillMaxSize()) {
            PhotoBackground(vm)
            val screen = if (vm.showAdd) 2 else if (vm.showMine) 3 else if (vm.showStarred) 4 else if (vm.showSettings) 1 else 0
            Crossfade(targetState = screen, label = "screen") { current ->
                when (current) {
                    2 -> AddTermScreen(vm)
                    3 -> MyTermsScreen(vm)
                    4 -> StarredScreen(vm)
                    1 -> SettingsScreen(vm)
                    else -> HomeScreen(vm)
                }
            }
            MenuDrawer(vm)
        }
    }
}
