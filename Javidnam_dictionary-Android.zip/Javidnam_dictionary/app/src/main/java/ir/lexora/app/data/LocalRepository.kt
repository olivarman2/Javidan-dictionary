package ir.lexora.app.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Offline dictionary: reads assets/terms.json (no internet needed).
 * Search order: exact match, then terms that start with the text, then terms that contain it.
 * Spellings are compared after unifying ی/ک, half-space and harakat (see PersianText.searchKey).
 */
class LocalRepository(private val context: Context, private val store: LocalStore) : TermRepository {

    private class Entry(val result: TermResult, val keys: List<String>)

    private var cache: List<Entry>? = null

    private suspend fun builtIn(): List<Entry> {
        cache?.let { return it }
        val loaded = withContext(Dispatchers.IO) {
            val text = context.applicationContext.assets.open("terms.json")
                .bufferedReader(Charsets.UTF_8).use { it.readText() }
            val arr = JSONArray(text)
            (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { parse(it, false) } }
        }
        cache = loaded
        return loaded
    }

    /** Terms added by the user come first, then the built-in dictionary. */
    private suspend fun entries(): List<Entry> {
        val user = store.loadUserTerms().mapNotNull { parse(it, true) }
        return user + builtIn()
    }

    suspend fun count(): Int = runCatching { entries().size }.getOrDefault(0)

    /** Titles that match what the user is typing (exact, then starts-with, then contains). */
    suspend fun suggest(query: String, limit: Int): List<String> {
        val key = PersianText.searchKey(query)
        if (key.isEmpty()) return emptyList()
        val all = try {
            entries()
        } catch (e: Exception) {
            return emptyList()
        }
        val exact = all.filter { e -> e.keys.any { it == key } }
        val prefix = all.filter { e -> e !in exact && e.keys.any { it.startsWith(key) } }
        val contains = all.filter { e -> e !in exact && e !in prefix && e.keys.any { it.contains(key) } }
        return (exact + prefix + contains).take(limit).map { it.result.displayTitle }
    }

    suspend fun userResults(): List<TermResult> =
        store.loadUserTerms().mapNotNull { parse(it, true)?.result }

    suspend fun exists(title: String): Boolean {
        val key = PersianText.searchKey(title)
        return entries().any { e -> e.keys.any { it == key } }
    }

    suspend fun findExact(title: String): TermResult? {
        val key = PersianText.searchKey(title)
        return entries().firstOrNull { e -> e.keys.any { it == key } }?.result
    }

    private fun parse(o: JSONObject, isUser: Boolean): Entry? {
        val title = o.str("t") ?: return null
        val plain = PersianText.sanitize(title)
        val aliases = o.optJSONArray("k").strings()
        val keys = (listOf(plain) + aliases).map { PersianText.searchKey(it) }.distinct()

        val similar = ArrayList<SimilarTerm>()
        val m = o.optJSONArray("m")
        if (m != null) {
            for (i in 0 until m.length()) {
                val pair = m.optJSONArray(i) ?: continue
                val term = pair.optString(0).trim()
                if (term.isNotEmpty()) similar.add(SimilarTerm(term, pair.optString(1).trim()))
            }
        }
        val result = TermResult(
            query = plain,
            mode = ResultMode.LOCAL,
            titleWithHarakat = title,
            pronunciation = o.str("p"),
            generalMeaning = o.str("g"),
            legalMeaning = o.str("l"),
            simpleExplanation = o.str("s"),
            examples = o.optJSONArray("e").strings(),
            similarTerms = similar,
            note = if (isUser) USER_NOTE else NOTE,
            category = if (isUser) USER_CATEGORY else o.str("c")
        )
        return Entry(result, keys)
    }

    override suspend fun search(query: String): SearchOutcome {
        val all = try {
            entries()
        } catch (e: Exception) {
            return SearchOutcome.Failure("خواندن پایگاه داده برنامه ممکن نشد.")
        }
        val key = PersianText.searchKey(query)
        if (key.isEmpty()) return SearchOutcome.NoSources("لطفاً یک کلمه یا اصطلاح وارد کنید.")

        val exact = all.filter { e -> e.keys.any { it == key } }
        val prefix = all.filter { e -> e !in exact && e.keys.any { it.startsWith(key) } }
        val contains = all.filter { e -> e !in exact && e !in prefix && e.keys.any { it.contains(key) } }
        val ranked = exact + prefix + contains

        if (ranked.isEmpty()) {
            return SearchOutcome.NoSources("«$query» در پایگاه داده برنامه پیدا نشد. املای دیگری را امتحان کنید.")
        }
        val related = ranked.drop(1).take(8).map { it.result.displayTitle }
        return SearchOutcome.Success(ranked.first().result.copy(related = related))
    }

    companion object {
        const val USER_CATEGORY = "افزوده‌شده توسط شما"
        private const val USER_NOTE = "این اصطلاح را خودتان اضافه کرده‌اید؛ توضیح آن بازبینی نشده است."
        private const val NOTE = "توضیح آموزشی نوشته‌شده برای این برنامه؛ ماده قانونی یا منبع رسمی ندارد. برای کار رسمی به متن قانون و وکیل مراجعه کنید."
    }
}
