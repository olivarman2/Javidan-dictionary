package ir.lexora.app.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ir.lexora.app.data.BackendRepository
import ir.lexora.app.data.LocalRepository
import ir.lexora.app.data.LocalStore
import ir.lexora.app.data.PersianText
import ir.lexora.app.data.SearchOutcome
import ir.lexora.app.data.TermRepository
import ir.lexora.app.data.TermResult
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import org.json.JSONObject

sealed interface UiState {
    object Idle : UiState
    object Loading : UiState
    data class Content(val result: TermResult) : UiState
    data class Message(val text: String, val isError: Boolean) : UiState
}

class LexoraViewModel(app: Application) : AndroidViewModel(app) {
    private val store = LocalStore(app)
    private val local = LocalRepository(app, store)
    private var job: Job? = null

    var query by mutableStateOf("")
    var uiState by mutableStateOf<UiState>(UiState.Idle)
    var history by mutableStateOf(store.loadHistory())
    var favorites by mutableStateOf(store.loadFavorites())
    var backendUrl by mutableStateOf(store.backendUrl)
    var showSettings by mutableStateOf(false)
    var termCount by mutableStateOf(0)
    var showAdd by mutableStateOf(false)
    var showMine by mutableStateOf(false)
    var showStarred by mutableStateOf(false)
    var menuOpen by mutableStateOf(false)
    var bgBlur by mutableStateOf(store.bgBlur)
    var wallpaperVersion by mutableStateOf(0)
    var suggestions by mutableStateOf<List<String>>(emptyList())
    private var suggestJob: Job? = null
    var myTerms by mutableStateOf<List<TermResult>>(emptyList())
    var addError by mutableStateOf<String?>(null)

    init {
        viewModelScope.launch { termCount = local.count() }
    }

    val isOnlineConfigured: Boolean get() = isValidBackendUrl(backendUrl)

    fun onQueryChange(value: String) {
        if (value.length <= MAX_QUERY_LENGTH + 20) query = value
        updateSuggestions()
    }

    private fun updateSuggestions() {
        suggestJob?.cancel()
        val q = query
        if (PersianText.searchKey(q).isEmpty()) {
            suggestions = emptyList()
            return
        }
        suggestJob = viewModelScope.launch { suggestions = local.suggest(q, 15) }
    }

    fun search(raw: String = query) {
        suggestJob?.cancel()
        suggestions = emptyList()
        val cleaned = PersianText.sanitize(raw)
        when {
            cleaned.isEmpty() -> {
                uiState = UiState.Message("لطفاً یک کلمه یا اصطلاح حقوقی وارد کنید.", false); return
            }
            cleaned.length > MAX_QUERY_LENGTH -> {
                uiState = UiState.Message("عبارت خیلی طولانی است. حداکثر $MAX_QUERY_LENGTH نویسه.", false); return
            }
            cleaned.none { it.isLetterOrDigit() } -> {
                uiState = UiState.Message("ورودی معتبر نیست. فقط حروف و عدد وارد کنید.", false); return
            }
        }
        query = cleaned
        job?.cancel()
        uiState = UiState.Loading

        val url = backendUrl.trim()
        val repo: TermRepository = if (isValidBackendUrl(url)) BackendRepository(url) else local
        job = viewModelScope.launch {
            uiState = when (val out = repo.search(cleaned)) {
                is SearchOutcome.Success -> {
                    store.addHistory(cleaned)
                    history = store.loadHistory()
                    UiState.Content(out.result)
                }
                is SearchOutcome.NoSources -> UiState.Message(out.message, false)
                is SearchOutcome.Failure -> UiState.Message(out.message, true)
            }
        }
    }

    fun clearQuery() {
        suggestJob?.cancel()
        suggestions = emptyList()
        job?.cancel()
        query = ""
        uiState = UiState.Idle
    }

    fun openFavorite(result: TermResult) {
        job?.cancel()
        query = result.query
        uiState = UiState.Content(result)
    }

    fun isFavorite(result: TermResult): Boolean = favorites.any { it.favoriteKey == result.favoriteKey }

    fun toggleFavorite(result: TermResult) {
        favorites = if (isFavorite(result)) {
            favorites.filterNot { it.favoriteKey == result.favoriteKey }
        } else {
            listOf(result) + favorites
        }
        store.saveFavorites(favorites)
    }

    fun setBlur(value: Float) {
        bgBlur = value
        store.bgBlur = value
    }

    fun importWallpaper(uri: Uri) {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { Wallpaper.importFrom(ctx, uri) }
            wallpaperVersion++
        }
    }

    fun resetWallpaper() {
        Wallpaper.reset(getApplication<Application>())
        wallpaperVersion++
    }

    fun openMine() {
        viewModelScope.launch {
            myTerms = local.userResults()
            showMine = true
        }
    }

    private fun refreshMine() {
        viewModelScope.launch { myTerms = local.userResults() }
    }

    private fun starKey(name: String) = PersianText.searchKey(name)

    fun isStarred(name: String): Boolean = favorites.any { it.favoriteKey == starKey(name) }

    /** Star/unstar any word by its name (used in lists, history and related terms). */
    fun toggleStar(name: String) {
        if (isStarred(name)) {
            favorites = favorites.filterNot { it.favoriteKey == starKey(name) }
            store.saveFavorites(favorites)
        } else {
            viewModelScope.launch {
                val found = local.findExact(name) ?: return@launch
                favorites = listOf(found) + favorites
                store.saveFavorites(favorites)
            }
        }
    }

    /** Validates and saves a term written by the user, then opens it. */
    fun submitTerm(term: String, pronunciation: String, meaning: String, explanation: String) {
        val t = term.trim()
        val error = when {
            t.isEmpty() || meaning.isBlank() || explanation.isBlank() -> "اصطلاح، معنا و توضیح را کامل کنید."
            t.length > MAX_QUERY_LENGTH -> "اصطلاح خیلی طولانی است."
            PersianText.sanitize(t).none { it.isLetterOrDigit() } -> "اصطلاح معتبر نیست."
            meaning.length > 1500 || explanation.length > 3000 -> "متن معنا یا توضیح خیلی طولانی است."
            else -> null
        }
        if (error != null) { addError = error; return }
        viewModelScope.launch {
            if (local.exists(t)) { addError = "این اصطلاح قبلاً وجود دارد."; return@launch }
            val o = JSONObject().apply {
                put("t", t)
                if (pronunciation.isNotBlank()) put("p", pronunciation.trim())
                put("l", meaning.trim())
                put("s", explanation.trim())
            }
            store.addUserTerm(o)
            termCount = local.count()
            refreshMine()
            addError = null
            showAdd = false
            search(PersianText.sanitize(t))
        }
    }

    fun deleteUserTerm(result: TermResult) {
        store.removeUserTerm(result.favoriteKey)
        favorites = favorites.filterNot { it.favoriteKey == result.favoriteKey }
        store.saveFavorites(favorites)
        viewModelScope.launch { termCount = local.count() }
        refreshMine()
        clearQuery()
    }

    fun clearHistory() {
        store.clearHistory()
        history = emptyList()
    }

    fun clearFavorites() {
        favorites = emptyList()
        store.saveFavorites(emptyList())
    }

    fun saveBackendUrl(url: String) {
        backendUrl = url.trim()
        store.backendUrl = backendUrl
    }

    companion object {
        const val MAX_QUERY_LENGTH = 100
        fun isValidBackendUrl(url: String): Boolean {
            val u = url.trim()
            return (u.startsWith("https://") || u.startsWith("http://")) && u.length > 10 && !u.contains(' ')
        }
    }
}
