package ir.lexora.app.data

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder
import java.net.UnknownHostException

interface TermRepository {
    suspend fun search(query: String): SearchOutcome
}

/**
 * Talks to YOUR backend (see /backend). The backend holds the secret API keys,
 * so the app itself never contains any key. Network work runs on Dispatchers.IO.
 */
class BackendRepository(private val baseUrl: String) : TermRepository {

    override suspend fun search(query: String): SearchOutcome = withContext(Dispatchers.IO) {
        var conn: HttpURLConnection? = null
        try {
            val url = URL(baseUrl.trimEnd('/') + "/api/search?q=" + URLEncoder.encode(query, "UTF-8"))
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 15_000
                readTimeout = 60_000
                setRequestProperty("Accept", "application/json")
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            when {
                code in 200..299 -> parseBody(body, query)
                code == 429 -> SearchOutcome.Failure("تعداد درخواست‌ها زیاد است. کمی بعد دوباره تلاش کنید.")
                code in 500..599 -> SearchOutcome.Failure(
                    serverMessage(body) ?: "خطای سرور (کد $code). کمی بعد دوباره تلاش کنید."
                )
                else -> SearchOutcome.Failure(serverMessage(body) ?: "پاسخ ناشناخته از سرور (کد $code).")
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: UnknownHostException) {
            SearchOutcome.Failure("اتصال به اینترنت یا آدرس سرور برقرار نشد.")
        } catch (e: SocketTimeoutException) {
            SearchOutcome.Failure("سرور دیر پاسخ داد. دوباره تلاش کنید.")
        } catch (e: IOException) {
            SearchOutcome.Failure("خطای شبکه. اتصال اینترنت و آدرس سرور را بررسی کنید.")
        } catch (e: JSONException) {
            SearchOutcome.Failure("پاسخ سرور قابل خواندن نبود.")
        } catch (e: Exception) {
            SearchOutcome.Failure("خطای غیرمنتظره رخ داد.")
        } finally {
            conn?.disconnect()
        }
    }

    private fun serverMessage(body: String): String? =
        runCatching { JSONObject(body).str("message") }.getOrNull()

    private fun parseBody(body: String, query: String): SearchOutcome {
        val root = JSONObject(body)
        return when (root.optString("status")) {
            "ok" -> SearchOutcome.Success(TermJson.parse(root, query, ResultMode.ONLINE))
            "no_sources" -> SearchOutcome.NoSources(
                root.str("message") ?: "منبع حقوقی قابل اعتمادی برای این عبارت پیدا نشد."
            )
            else -> SearchOutcome.Failure(root.str("message") ?: "سرور خطا برگرداند.")
        }
    }
}
