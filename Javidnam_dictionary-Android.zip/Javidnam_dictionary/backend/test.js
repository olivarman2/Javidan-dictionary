// Run: node test.js  (no keys or internet needed)
import assert from 'node:assert/strict';
import { normalize, squash, verifyArticles, extractJson } from './server.js';

const sources = [{ url: 'https://rc.majlis.ir/x', content: 'ماده ۶۵۶ - وکالت عقدی است که به موجب آن یکی از طرفین طرف دیگر را برای انجام امری نایب خود قرار می‌دهد.' }];

assert.equal(normalize('كتاب يك'), 'کتاب یک');
assert.equal(squash('وکالت‌نامه'), squash('وکالت نامه'));

// real quote -> kept
let ok = verifyArticles([{ reference: 'ماده ۶۵۶', evidence: 'عقدی است که به موجب آن یکی از طرفین', sourceIndex: 0 }], sources);
assert.equal(ok.length, 1);
assert.equal(ok[0].sourceUrl, 'https://rc.majlis.ir/x');

// invented quote -> dropped
assert.equal(verifyArticles([{ reference: 'ماده ۹۹۹', evidence: 'این جمله اصلاً در منبع وجود ندارد و ساختگی است', sourceIndex: 0 }], sources).length, 0);
// too short -> dropped
assert.equal(verifyArticles([{ reference: 'ماده ۱', evidence: 'وکالت', sourceIndex: 0 }], sources).length, 0);
// malformed -> dropped
assert.equal(verifyArticles([null, {}, { reference: 1 }], sources).length, 0);

assert.deepEqual(extractJson('```json\n{"a":1}\n```'), { a: 1 });
console.log('All backend tests passed ✔');
