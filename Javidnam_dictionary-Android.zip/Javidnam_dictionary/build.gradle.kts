// Top-level build file. Versions are pinned to a stable, compatible set:
// AGP 8.5.2 + Gradle 8.7 + Kotlin 1.9.24 + Compose compiler 1.5.14 + JDK 17.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
